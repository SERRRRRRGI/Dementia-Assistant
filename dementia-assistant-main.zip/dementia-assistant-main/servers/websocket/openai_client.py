from dotenv import load_dotenv
load_dotenv()

from openai import OpenAI

OPENAI_CLIENT = OpenAI()