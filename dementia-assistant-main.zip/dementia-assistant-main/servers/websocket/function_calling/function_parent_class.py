class OpenAIFunction:
    description: dict[str, str]
    meanwhile: list[str]

    def apply(args: dict[str, str]) -> any :
        pass

    @staticmethod
    def getName() -> str:
        pass